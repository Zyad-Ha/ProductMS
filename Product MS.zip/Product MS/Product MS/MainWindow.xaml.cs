﻿using Azure;
using Product_MS.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Product_MS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Context _context = new Context();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Loginbtn_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(nametxtb.Text) ||
                string.IsNullOrWhiteSpace(passtxtb.Text))
            {
                MessageBox.Show("Please fill all boxes.");
            }

            var query = (from x in _context.users
                         where x.userName == nametxtb.Text && 
                         x.password == passtxtb.Text
                         select x).FirstOrDefault();
            string? name = query.userName;
            if (query != null) 
            {
                if (query.role == "customer")
                {
                    Label1.Content = " ";
                    MessageBox.Show("Login Successfully.");
                    CustomerWindow customerWindow = new CustomerWindow(name);
                    customerWindow.Show();
                    this.Close();
                }
                else if (query.role == "admin")
                {
                    Label1.Content = " ";
                    MessageBox.Show("Login Successfully.");
                    AdminWindow adminWindow = new AdminWindow();
                    adminWindow.Show();
                    this.Close();
                }
            }
            else
            {
                Label1.Content = "Invalid name or password.";
            }


        }
    }
}