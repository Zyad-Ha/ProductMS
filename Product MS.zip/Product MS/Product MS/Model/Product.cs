﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product_MS.Model
{
    internal class Product
    {
       
        public string? productName{ get; set; }
        [Key]
        public int? proId{ get; set; }
        public int? inStockQuantity{ get; set; }
        public string? description{ get; set; }
    }
}
