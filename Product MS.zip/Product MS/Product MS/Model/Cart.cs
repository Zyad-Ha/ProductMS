﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product_MS.Model
{
    internal class Cart
    {
        public string? Cname { get; set; }
        [ForeignKey("userId")]
        public int? u_id { get; set; }

        [Key]
        public int? CartId { get; set; }
        public int? totalPrice { get; set; }

    }
}
