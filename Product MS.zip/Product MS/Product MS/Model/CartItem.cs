﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product_MS.Model
{
    internal class CartItem
    {
        public int? cartItemId { get; set; }
        public int? quantity{ get; set; }
        [ForeignKey("CartId")]
        public int? c_id { get; set; }
        [ForeignKey("proId")]
        public int? pro_id { get; set; }

    }
}
