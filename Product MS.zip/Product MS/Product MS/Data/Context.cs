﻿using Microsoft.EntityFrameworkCore;
using Product_MS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product_MS.Data
{
    internal class Context :DbContext
    {
        public Context() {  }

        public Context(DbContextOptions options) : base(options) { }

        public DbSet<Users> users { get; set; }
        public DbSet<CartItem> partItems  { get; set; }
        public DbSet<Product>  poducts  { get; set; }
        public DbSet<Cart> carts  { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=COM184-LAB3\\SQLEXPRESS;Initial Catalog=ProductMS;Integrated Security=True;Trust Server Certificate=True");
            }
        }


    }
}
